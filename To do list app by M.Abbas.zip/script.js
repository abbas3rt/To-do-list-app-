document.addEventListener("DOMContentLoaded", function() {
  // Load tasks from local storage
  loadTasks();
});

function addTask() {
  var taskInput = document.getElementById("taskInput").value;

  if (taskInput.trim() !== "") {
    var incompleteTasksDiv = document.getElementById("incompleteTasks");

    // Create a new task item
    var taskItem = document.createElement("div");
    taskItem.innerHTML = '<input type="checkbox" onchange="completeTask(this)">' + taskInput;

    // Add the task item to the incomplete tasks div
    incompleteTasksDiv.appendChild(taskItem);

    // Save tasks to local storage
    saveTasks();

    // Clear the input field
    document.getElementById("taskInput").value = "";
  }
}

function completeTask(checkbox) {
  var completedTasksDiv = document.getElementById("completedTasks");
  var taskItem = checkbox.parentNode; // Get the parent div of the checkbox

  if (checkbox.checked) {
    // Move the task to the completed tasks div
    completedTasksDiv.appendChild(taskItem);
    // Apply line-through style to the task title
    taskItem.style.textDecoration = "line-through";
  } else {
    // Move the task back to the incomplete tasks div
    document.getElementById("incompleteTasks").appendChild(taskItem);
    // Remove the line-through style
    taskItem.style.textDecoration = "none";
  }

  // Save tasks to local storage
  saveTasks();
}

function saveTasks() {
  var incompleteTasks = document.getElementById("incompleteTasks").innerHTML;
  var completedTasks = document.getElementById("completedTasks").innerHTML;

  localStorage.setItem("incompleteTasks", incompleteTasks);
  localStorage.setItem("completedTasks", completedTasks);
}

function loadTasks() {
  var incompleteTasks = localStorage.getItem("incompleteTasks");
  var completedTasks = localStorage.getItem("completedTasks");

  if (incompleteTasks) {
    document.getElementById("incompleteTasks").innerHTML = incompleteTasks;
  }

  if (completedTasks) {
    document.getElementById("completedTasks").innerHTML = completedTasks;
  }
}

function deleteTask(taskItem) {
  // Remove the task from its parent
  taskItem.parentNode.removeChild(taskItem);

  // Save tasks to local storage
  saveTasks();
}

// Add event listener for double-click to delete
document.getElementById("incompleteTasks").addEventListener("dblclick", function(event) {
  // Check if the target is a task item
  if (event.target.nodeName === "DIV" && event.target.parentNode.id === "incompleteTasks") {
    deleteTask(event.target);
  }
});